/**
Copyright 2004 Juan Heyns. All rights reserved.

Redistribution and use in source and binary forms, with or without modification, are
permitted provided that the following conditions are met:

   1. Redistributions of source code must retain the above copyright notice, this list of
      conditions and the following disclaimer.

   2. Redistributions in binary form must reproduce the above copyright notice, this list
      of conditions and the following disclaimer in the documentation and/or other materials
      provided with the distribution.

THIS SOFTWARE IS PROVIDED BY JUAN HEYNS ``AS IS'' AND ANY EXPRESS OR IMPLIED
WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND
FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL JUAN HEYNS OR
CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF
ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

The views and conclusions contained in the software and documentation are those of the
authors and should not be interpreted as representing official policies, either expressed
or implied, of Juan Heyns.
*/
package org.jdatepicker;

import javax.swing.JComponent;
import javax.swing.JFrame;
import javax.swing.WindowConstants;


public class TestJDatePanel {

    public static void main(String[] args) {
        // Test 1: Monday is the first day of week (Germany)
//        Locale.setDefault(Locale.GERMAN);

//        // Test 2: Saturday is the first day of week (Saudi Arabia)
//        Locale.setDefault(new Locale("ar", "sa"));

//        // Test 3: Sunday is the first day of week (US)
//        Locale.setDefault(Locale.US);
        
        JFrame testFrame = new JFrame();
        JDatePanel panel = new DefaultComponentFactory().createJDatePanel();
        panel.setShowYearButtons(true);
        testFrame.getContentPane().add((JComponent)panel);
        panel.setShowYearButtons(false);
        panel.setShowYearButtons(true);

        testFrame.setSize(300,300);
        testFrame.setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
        testFrame.setVisible(true);
    }

}
